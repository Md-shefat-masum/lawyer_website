<div class="input-group">
    <div class="input-group-prepend search-arrow-back">
        <button class="btn btn-search-back" type="button"><i class="zmdi zmdi-long-arrow-left"></i></button>
    </div>
    <input type="text" class="form-control" placeholder="search" />
    <div class="input-group-append">
        <button class="btn btn-search" type="button"><i class="zmdi zmdi-search"></i></button>
    </div>
</div>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/layouts/admin/top_search.blade.php ENDPATH**/ ?>