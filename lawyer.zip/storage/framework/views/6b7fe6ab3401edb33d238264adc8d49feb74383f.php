<?php $__env->startSection('content'); ?>



    <!-- Main content Start -->
    <div class="main-content">

        <?php echo $__env->make('website.home_page_include.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <?php echo $__env->make('website.home_page_include.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Services Start -->
        <div id="rs-services" class="rs-services style1 long-gap md-pt-80">
            <div class="container">
                <div class="row rs-vertical-middle">
                    <div class="col-lg-12">
                        <div class="service-inner">
                            <div class="service-box">
                                <div class="service_image">
                                    <img src="/contents/website/a.JPG" style="width: 100%" alt="">
                                    <div class="caption">
                                        <p>No more legal worries.</p>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="service-box dark-bg">
                                <div class="service_image">
                                    <img src="/contents/website/b.jpg" style="width: 100%" alt="">
                                    <div class="caption">
                                        <p>Timely response is important.</p>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="service-box">
                                <div class="service_image">
                                    <img src="/contents/website/c.jpg" style="width: 100%" alt="">
                                    <div class="caption">
                                        <p>Getting your life on the right path.</p>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Services End -->

        <br>
        <br>
        
        <?php echo $__env->make('website.home_page_include.practice_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Faq Section Start -->
        <div class="rs-faq style1 pt-120 pb-120 md-pt-72 md-pb-80 ">
            <div class="container padding-0 md-pr-15 md-pl-15 ">
                <div class="content-wrap title-bg ">
                    <div class="row md-col-padding ">
                        <div class="col-lg-6 pr-0 ">
                            <div class="faq-part ">
                                <div class="sec-title mb-45 xs-mb-31 ">
                                    <div class="sub-title primary ">Any Questions ?</div>
                                    <h2 class="title white-color mb-0 ">Frequently Asked Questions</h2>
                                </div>
                                <div id="accordion" class="accordion">

                                    <?php $__currentLoopData = App\FAQ::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card">
                                            <div class="card-header ">
                                                <a class="card-link " data-toggle="collapse" href="#collapseOne<?php echo e($item->id); ?>">
                                                    Q. <?php echo e($key+1); ?> : <?php echo e($item->question); ?>

                                                </a>
                                            </div>
                                            <div id="collapseOne<?php echo e($item->id); ?>" class="collapse <?php echo e($key==0?'show':''); ?>" data-parent="#accordion">
                                                <div class="card-body ">
                                                    <?php echo e($item->answer); ?>

                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 pl-0 ">
                            <?php echo $__env->make('website.home_page_include.free_consultation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Faq Section End -->

        <!-- Testimonia Section Start -->
        
        <!-- Testimonia Section End -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/njahanlaw/public_html/resources/views/website/index.blade.php ENDPATH**/ ?>