<?php $__env->startSection('content'); ?>

    

    <!--End Dashboard Content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/njahanlaw/public_html/resources/views/admin/index.blade.php ENDPATH**/ ?>