<div class="card-body">
    <div class="table-responsive">
        <table class="table text-center">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">email</th>
                    <th scope="col">phone</th>
                    <th scope="col">law Type</th>
                    <th scope="col">description</th>
                    <th scope="col">Created at</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; ?>

                <?php $__currentLoopData = $free_consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->law->name); ?></td>
                        <td><?php echo e($item->message); ?></td>
                        <td><?php echo e($item->created_at->format('d-M-Y h:i:s a')); ?></td>
                        <td>
                            <ul class="d-flex justify-content-center table_action_list">
                                <li><a class="data_view_btn" href="<?php echo e(route('admin_free_consultation_view',$item->id)); ?>"><i class="fa fa-plus"></i></a></li>
                                <li>
                                    <a href="#" class="edit_btn"
                                        data-href="<?php echo e(route('admin_free_consultation_update')); ?>"
                                        data-edit_href="<?php echo e(route('admin_free_consultation_edit')); ?>?id=<?php echo e($item->id); ?>"
                                        data-toggle="modal" data-target="#formemodal">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                </li>
                                <li><a href="#" data-href="<?php echo e(route('admin_free_consultation_delete', $item->id)); ?>"
                                        class="delete_btn" data-toggle="modal"
                                        data-target="#modal-animation-1"><i class="fa fa-trash"></i></a>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="card-footer">
    <?php echo e($free_consultations->links()); ?>

</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/free_consultation/table_data.blade.php ENDPATH**/ ?>