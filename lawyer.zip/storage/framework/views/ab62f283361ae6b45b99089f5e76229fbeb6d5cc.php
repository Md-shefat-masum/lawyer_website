<!-- Slider Start -->
<div id="rs-slider" class="rs-slider slider1">
    <div class="bend niceties">
        <div id="nivoSlider" class="slides">
            <?php $i = 1; ?>
            <?php $__currentLoopData = App\Banner::where('status',1)->latest()->get()->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset(''.$item->banner_image)); ?>" alt="banner" title="#slide-<?php echo e($i++); ?>" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- Slide 1 -->
        <?php $i=1; ?>
        <?php $__currentLoopData = App\Banner::where('status',1)->latest()->get()->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="slide-<?php echo e($i++); ?>" class="slider-direction">
                <div class="container h-100">
                    <div class="row align-items-center h-100">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-7">
                            <div class="content-part" style="background-color: transparent; margin-top: 17%;">
                                <div class="slider-des" style="text-align: center;">

                                    <h4 class="black-color" style="font-family: Anton !important;"><?php echo e($item->heading_1); ?></h4>
                                    <h2 class="black-color" style="font-family: Anton !important;">
                                        <?php echo e($item->heading_2); ?>

                                    </h2>

                                </div>

                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<!-- Slider End -->
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/website/home_page_include/slider.blade.php ENDPATH**/ ?>