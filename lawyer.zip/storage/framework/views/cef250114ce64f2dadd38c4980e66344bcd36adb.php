<nav class="navbar navbar-expand fixed-top">
    <div class="toggle-menu">
        <i class="zmdi zmdi-menu"></i>
    </div>

    <div class="search-bar flex-grow-1 d-none">
        <?php echo $__env->make('layouts.admin.top_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <ul class="navbar-nav align-items-center right-nav-link ml-auto">
        <li class="nav-item dropdown search-btn-mobile">
            <a class="nav-link position-relative" href="javascript:void();">
                <i class="zmdi zmdi-search align-middle"></i>
            </a>
        </li>

        <li class="nav-item dropdown dropdown-lg d-none">
            <?php echo $__env->make('layouts.admin.top_message_alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>

        <li class="nav-item dropdown dropdown-lg d-none">
            <?php echo $__env->make('layouts.admin.top_notification_alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>

        <li class="nav-item dropdown language d-none">
            <a class="nav-link dropdown-toggle dropdown-toggle-nocaret position-relative" data-toggle="dropdown" href="javascript:void();"><i class="flag-icon flag-icon-gb align-middle"></i></a>
            <ul class="dropdown-menu dropdown-menu-right">
                <li class="dropdown-item"><i class="flag-icon flag-icon-gb mr-3"></i>English</li>
            </ul>
        </li>

        <li class="nav-item dropdown">
            <?php echo $__env->make('layouts.admin.top_right_profile_action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>
    </ul>
</nav>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/layouts/admin/topbar.blade.php ENDPATH**/ ?>