<input type="hidden"  name="id" value="<?php echo e($data->id); ?>" id="">

<div class="form-group">
    <label for="input-1">Email</label> <span class="text-danger">*</span>
    <input type="text" name="email" class="form-control" placeholder="name" value="<?php echo e($data->email); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/subscriber/edit.blade.php ENDPATH**/ ?>