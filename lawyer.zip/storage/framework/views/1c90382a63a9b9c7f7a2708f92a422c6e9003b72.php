
    <div class="table-responsive">
        <table class="table text-center">
            <tr>
                <th>First name</th>
                <th>:</th>
                <th><?php echo e($data->first_name); ?></th>
            </tr>
            <tr>
                <th>middle name</th>
                <th>:</th>
                <th><?php echo e($data->middle_name); ?></th>
            </tr>
            <tr>
                <th>Last name</th>
                <th>:</th>
                <th><?php echo e($data->last_name); ?></th>
            </tr>
            <tr>
                <th>Spouse First name</th>
                <th>:</th>
                <th><?php echo e($data->spouse_first_name); ?></th>
            </tr>
            <tr>
                <th>Spouse middle name</th>
                <th>:</th>
                <th><?php echo e($data->spouse_middle_name); ?></th>
            </tr>
            <tr>
                <th>Spouse Last name</th>
                <th>:</th>
                <th><?php echo e($data->spouse_last_name); ?></th>
            </tr>
            <tr>
                <th>gender</th>
                <th>:</th>
                <th><?php echo e($data->gender); ?></th>
            </tr>
            <tr>
                <th>Date of birth</th>
                <th>:</th>
                <th><?php echo e($data->date_of_birth); ?></th>
            </tr>
            <tr>
                <th>Marital Status</th>
                <th>:</th>
                <th><?php echo e($data->marital_status); ?></th>
            </tr>
            <tr>
                <th>Number of children</th>
                <th>:</th>
                <th><?php echo e($data->number_of_children); ?></th>
            </tr>
            <tr>
                <th>email</th>
                <th>:</th>
                <th><?php echo e($data->email); ?></th>
            </tr>
            <tr>
                <th>phone</th>
                <th>:</th>
                <th><?php echo e($data->phone); ?></th>
            </tr>
            <tr>
                <th>citizenship</th>
                <th>:</th>
                <th><?php echo e($data->citizenship); ?></th>
            </tr>
            <tr>
                <th>Residential Address</th>
                <th>:</th>
                <th><?php echo e($data->residential_address); ?></th>
            </tr>
            <tr>
                <th>Legal Status</th>
                <th>:</th>
                <th><?php echo e($data->legal_status); ?></th>
            </tr>
            
            <tr>
                <th>Website</th>
                <th>:</th>
                <th><?php echo e($data->website); ?></th>
            </tr>
            <tr>
                <th>message</th>
                <th>:</th>
                <th style="white-space: break-spaces"><?php echo e($data->message); ?></th>
            </tr>
            <tr>
                <th>message</th>
                <th>:</th>
                <th style="white-space: break-spaces"><?php echo e($data->message); ?></th>
            </tr>
            <tr>
                <th>Created at</th>
                <th>:</th>
                <th><?php echo e($data->created_at->format('d,M Y h:s:i a')); ?></th>
            </tr>
        </table>
        <table class="table text-center">
            <tr>
                <th>From <br> Month/Year</th>
                <th>To <br> Month/Year</th>
                <th>Name of the institution <br> (start with the recent eduction)</th>
                <th>City,Country</th>
                <th>Certificate, Diploma or degree issued, <br> field of study and major <br>(as it is indicated in your diploma)</th>
            </tr>
            <?php
                $cirtificates = json_decode($data->cirtificate);
            ?>
            <?php $__currentLoopData = $cirtificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cirtificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cirtificate->from); ?></td>
                    <td><?php echo e($cirtificate->to); ?></td>
                    <td><?php echo e($cirtificate->name_of_institue); ?></td>
                    <td><?php echo e($cirtificate->city_country); ?></td>
                    <td><?php echo e($cirtificate->certificate_degree); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <style>
            .table td, .table th{
                text-transform: capitalize;
            }
        </style>
    </div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/contact_us_message/view.blade.php ENDPATH**/ ?>