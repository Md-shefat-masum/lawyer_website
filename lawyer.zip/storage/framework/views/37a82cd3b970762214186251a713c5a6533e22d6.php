
<div class="form-group">
    <label for="input-1">Name</label> <span class="text-danger">*</span>
    <input type="text" name="name" class="form-control" placeholder="name" value="<?php echo e(old('name')); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/law_list/add.blade.php ENDPATH**/ ?>