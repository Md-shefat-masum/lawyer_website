
<div class="form-group">
    <label for="input-1">Question</label> <span class="text-danger">*</span>
    <input type="text" name="question" class="form-control" placeholder="Question" value="<?php echo e(old('question')); ?>">
</div>
<div class="form-group">
    <label for="input-1">Answer</label> <span class="text-danger">*</span>
    <input type="text" name="answer" class="form-control" placeholder="answer" value="<?php echo e(old('answer')); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/faq/add.blade.php ENDPATH**/ ?>