<div class="brand-logo">
    <img src="http://hsblco.com/uploads/favicon_1588291670.jpg" class="logo-icon" alt="logo icon" />
    <h5 class="logo-text">Admin Panel</h5>
    <div class="close-btn"><i class="zmdi zmdi-close"></i></div>
</div>
<?php /**PATH /home1/njahanlaw/public_html/resources/views/layouts/admin/logo.blade.php ENDPATH**/ ?>