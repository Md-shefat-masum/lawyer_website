<input type="hidden"  name="id" value="<?php echo e($data->id); ?>" id="">

<div class="form-group">
    <label for="input-1">name</label> <span class="text-danger">*</span>
    <input type="text" name="name" class="form-control" placeholder="name" value="<?php echo e($data->name); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/law_list/edit.blade.php ENDPATH**/ ?>