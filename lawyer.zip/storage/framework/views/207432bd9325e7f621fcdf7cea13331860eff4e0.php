<div class="input-group">
    <div class="input-group-prepend search-arrow-back">
        <button class="btn btn-search-back" type="button"><i class="zmdi zmdi-long-arrow-left"></i></button>
    </div>
    <input type="text" class="form-control" placeholder="search" />
    <div class="input-group-append">
        <button class="btn btn-search" type="button"><i class="zmdi zmdi-search"></i></button>
    </div>
</div>
<?php /**PATH /home1/njahanlaw/public_html/resources/views/layouts/admin/top_search.blade.php ENDPATH**/ ?>