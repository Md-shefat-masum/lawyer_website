
<div class="form-group">
    <label for="input-1">Name</label> <span class="text-danger">*</span>
    <input type="text" name="name" class="form-control" placeholder="name" value="">
</div>
<div class="form-group">
    <label for="input-1">Email</label> <span class="text-danger">*</span>
    <input type="text" name="email" class="form-control" placeholder="email" value="">
</div>
<div class="form-group">
    <label for="input-1">phone</label> <span class="text-danger">*</span>
    <input type="text" name="phone" class="form-control" placeholder="phone" value="">
</div>
<div class="form-group">
    <label for="input-1">law_name</label> <span class="text-danger">*</span>
    
    <select name="law_name" class="form-control">
        <?php $__currentLoopData = App\LawList::OrderBy('name','ASC')->where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<div class="form-group">
    <label for="input-1">message</label> <span class="text-danger">*</span>
    <input type="text" name="message" class="form-control" placeholder="message" value="">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/free_consultation/add.blade.php ENDPATH**/ ?>