<?php $__env->startSection('content'); ?>



    <!-- Breadcrumbs Section Start -->
    <div class="rs-breadcrumbs innerbg5">
        <div class="container">
            <div class="breadcrumbs-inner text-center">
                <h1 class="breadcrumbs-title white-color">About Us</h1>
                <ul class="breadcrumbs-meta">
                    <li><a href="/">Home</a></li>
                    <li>About Us</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Section End -->

    <!-- About Section Start -->
    <div id="rs-about" class="rs-about style1 pt-120 pb-120 md-pt-80 md-pb-78">
        <div class="container">
            <div class="row rs-vertical-middle">
                <div class="col-lg-5 md-mb-30">
                    <img src="<?php echo e(asset(''.App\DescriptiveAbout::first()->image)); ?>" alt="">
                </div>
                <div class="col-lg-7 pl-45 md-pl-15">
                    <div class="sec-title mb-24">
                        <div class="sub-title primary">About Us</div>
                    </div>
                    <?php echo App\DescriptiveAbout::first()->description; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- About Section End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/njahanlaw/public_html/resources/views/website/about.blade.php ENDPATH**/ ?>