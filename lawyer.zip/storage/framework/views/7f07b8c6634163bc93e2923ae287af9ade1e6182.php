<div class="card-body">
    <div class="table-responsive">
        <table class="table text-center">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Heading one</th>
                    <th scope="col">Heading two</th>
                    <th scope="col">Banner Image</th>
                    <th scope="col">Created at</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; ?>

                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($item->heading_1); ?></td>
                        <td><?php echo e($item->heading_2); ?></td>
                        <td> <img src="/<?php echo e($item->banner_image); ?>" style="height: 40px;" alt=""></td>
                        <td><?php echo e($item->created_at->format('d-M-Y h:i:s a')); ?></td>
                        <td>
                            <ul class="d-flex justify-content-center table_action_list">
                                <li><a class="data_view_btn" href="<?php echo e(route('admin_banner_view',$item->id)); ?>"><i class="fa fa-plus"></i></a></li>
                                <li>
                                    <a href="#" class="edit_btn"
                                        data-href="<?php echo e(route('admin_banner_update')); ?>"
                                        data-edit_href="<?php echo e(route('admin_banner_edit')); ?>?id=<?php echo e($item->id); ?>"
                                        data-toggle="modal" data-target="#formemodal">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                </li>
                                <li><a href="#" data-href="<?php echo e(route('admin_banner_delete', $item->id)); ?>"
                                        class="delete_btn" data-toggle="modal"
                                        data-target="#modal-animation-1"><i class="fa fa-trash"></i></a>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="card-footer">
    <?php echo e($banners->links()); ?>

</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/banner/table_data.blade.php ENDPATH**/ ?>