
    <div class="table-responsive">
        <table class="table text-center">
            <tr>
                <th>email</th>
                <th>:</th>
                <th><?php echo e($data->email); ?></th>
            </tr>
            <tr>
                <th>Creator</th>
                <th>:</th>
                <th><?php echo e($data->creator); ?></th>
            </tr>
            <tr>
                <th>Created at</th>
                <th>:</th>
                <th><?php echo e($data->created_at->format('d,m Y h:s:i a')); ?></th>
            </tr>
            <tr>
                <th>Updated at</th>
                <th>:</th>
                <th><?php echo e($data->updated_at->format('d,m Y h:s:i a')); ?></th>
            </tr>
        </table>
    </div>
<?php /**PATH /home/hsblco55/lawyer.hsblco.com/resources/views/admin/website/subscriber/view.blade.php ENDPATH**/ ?>