<?php echo $__env->make('layouts.admin.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<ul class="metismenu" id="menu">
    <li>
        <div class="side_bar_top">
            <img src="<?php echo e(asset(''.Auth::user()->photo)); ?>" alt="profile pic">
            <h6><?php echo e(Auth::user()->name); ?></h6>
        </div>
    </li>
    <li>
        <a href="/admin">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Dashboard</div>
        </a>
    </li>

    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-account-box-o"></i></div>
            <div class="menu-title">User Management</div>
        </a>
        <ul class="">
            <li>
                <a href="<?php echo e(route('admin_user_index')); ?>"><i class="zmdi zmdi-account-box-o"></i> All Users</a>
            </li>
        </ul>
    </li>

    <li>
        <a class="has-arrow" href="#">
            <div class="parent-icon"><i class="zmdi zmdi-globe"></i></div>
            <div class="menu-title">Website Management</div>
        </a>
        <ul class="">
            <li>
                <a class="has-arrow" href="#">
                    <div class="parent-icon"><i class="zmdi zmdi-home"></i></div>
                    <div class="menu-title">Home Page</div>
                </a>
                <ul class="">
                    <li>
                        <a href="<?php echo e(route('admin_about_us_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Basic Informations
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_banner_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Banner
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_short_about_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Short About Me
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_descriptive_about_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Descriptive About Me
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_area_of_practice_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Area Of Practice
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin_faq_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            FAQ
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_law_list_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Law List
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_free_consultation_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Free Consultation Requests
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_review_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Reviews
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin_subscriber_index')); ?>">
                            <i class="zmdi zmdi-dot-circle-alt"></i>
                            Subscribers
                        </a>
                    </li>
                </ul>
            </li>

            <li>
                <a href="<?php echo e(route('admin_service_index')); ?>">
                    <i class="zmdi zmdi-dot-circle-alt"></i>
                    Services
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_team_lead_index')); ?>">
                    <i class="zmdi zmdi-dot-circle-alt"></i>
                    Founder Lawer
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_our_privilege_index')); ?>">
                    <i class="zmdi zmdi-dot-circle-alt"></i>
                    Our Team
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('admin_contact_us_message_index')); ?>">
                    <i class="zmdi zmdi-dot-circle-alt"></i>
                    Contact Messages
                </a>
            </li>
        </ul>
    </li>

    

    <li class="menu-label">Extra</li>
    <li>
        <a href="/" target="_blank">
            <div class="parent-icon"><i class="zmdi zmdi-globe"></i></div>
            <div class="menu-title">Visit Site</div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <div class="parent-icon"><i class="zmdi zmdi-power-off"></i></div>
            <div class="menu-title">Logout</div>
        </a>
    </li>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</ul>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/layouts/admin/nav_sidebar.blade.php ENDPATH**/ ?>