<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="md.shefat" />
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <title>Admin panel</title>
        <!-- loader-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/css/pace.min.css" rel="stylesheet" />
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/js/pace.min.js"></script>
        <!--favicon-->
        <link rel="icon" href="http://hsblco.com/uploads/favicon_1588291670.jpg" type="image/x-icon" />
        <!-- simplebar CSS-->
        <?php echo $__env->yieldPushContent('cssplugin'); ?>
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
        <!-- Bootstrap core CSS-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
        <!-- animate CSS-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/css/animate.css" rel="stylesheet" type="text/css" />
        <!-- Icons CSS-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/css/icons.css" rel="stylesheet" type="text/css" />
        <!-- Metismenu CSS-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
        <!-- Custom Style-->
        <link href="<?php echo e(asset('contents/admin')); ?>/assets/css/app-style.css" rel="stylesheet" />
        <link href="<?php echo e(asset('contents/admin')); ?>/custom.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
        <?php echo $__env->yieldPushContent('css'); ?>
    </head>

    <body class="bg-theme bg-theme2">
        <?php echo $__env->make('include.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Start wrapper-->
        <div id="wrapper">

            <!--Start sidebar-wrapper-->
            <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
                <?php echo $__env->make('layouts.admin.nav_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!--End sidebar-wrapper-->

            <!--Start topbar header-->
            <header class="topbar-nav">
                <?php echo $__env->make('layouts.admin.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
            <!--End topbar header-->

            <div class="clearfix"></div>

            <div class="content-wrapper">
                <div class="container-fluid">
                    <!--Start Dashboard Content-->

                    <?php echo $__env->yieldContent('content'); ?>

                    <!--start overlay-->
                    <div class="overlay"></div>
                    <!--end overlay-->
                </div>
                <!-- End container-fluid-->
            </div>
            <!--End content-wrapper-->
            <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
            <!--End Back To Top Button-->

            <!--Start footer-->
            <footer class="footer">
                <div class="container">
                    <div class="text-center">
                        Copyright © 2020 Admin Panel
                    </div>
                </div>
            </footer>
            <!--End footer-->

            <!--start color switcher-->
            <div class="right-sidebar">
                <div class="switcher-icon">
                    <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
                </div>
                <div class="right-sidebar-content">
                    <p class="mb-0">Gaussion Texture</p>
                    <hr />

                    <ul class="switcher">
                        <li id="theme1"></li>
                        <li id="theme2"></li>
                        <li id="theme3"></li>
                        <li id="theme4"></li>
                        <li id="theme5"></li>
                        <li id="theme6"></li>
                    </ul>

                    <p class="mb-0">Gradient Background</p>
                    <hr />

                    <ul class="switcher">
                        <li id="theme7"></li>
                        <li id="theme8"></li>
                        <li id="theme9"></li>
                        <li id="theme10"></li>
                        <li id="theme11"></li>
                        <li id="theme12"></li>
                        <li id="theme13"></li>
                        <li id="theme14"></li>
                        <li id="theme15"></li>
                    </ul>
                </div>
            </div>
            <!--end color switcher-->
        </div>
        <!--End wrapper-->

        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/js/popper.min.js"></script>
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/js/bootstrap.min.js"></script>

        <!-- simplebar js -->
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/plugins/simplebar/js/simplebar.js"></script>
        <!-- Metismenu js -->
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/plugins/metismenu/js/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('contents/admin')); ?>/axios.js"></script>
        <?php echo $__env->yieldPushContent('jsplugin'); ?>
        <!-- Custom scripts -->
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/js/app-script.js"></script>
        <script src="<?php echo e(asset('contents/admin')); ?>/custom.js"></script>

        <?php echo $__env->yieldPushContent('js'); ?>

    </body>
</html>
<?php /**PATH /home/hsblco55/lawyer.hsblco.com/resources/views/layouts/admin/admin.blade.php ENDPATH**/ ?>