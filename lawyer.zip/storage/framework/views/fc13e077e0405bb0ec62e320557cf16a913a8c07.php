<!-- About Section Start -->
<div id="rs-about" class="rs-about style1 pt-120 pb-120 md-pt-80 md-pb-78">
    <div class="container">
        <div class="row rs-vertical-middle">
            <div class="col-lg-5 md-mb-30">
                <div class="about_image_left">
                    <img src="<?php echo e(asset(''.App\ShortAbout::first()->image)); ?>" alt="">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, enim? </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 pl-45 md-pl-15">
                <div class="sec-title mb-24">
                    <div class="sub-title primary">About Us</div>
                </div>
                <?php echo App\ShortAbout::first()->description; ?>

                <div class="btn-area pt-30">
                    <a href="/contact" class="readon">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About Section End -->
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/website/home_page_include/about.blade.php ENDPATH**/ ?>