<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaveForLater extends Model
{
    //
}
