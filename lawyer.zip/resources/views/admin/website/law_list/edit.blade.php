<input type="hidden"  name="id" value="{{ $data->id }}" id="">

<div class="form-group">
    <label for="input-1">name</label> <span class="text-danger">*</span>
    <input type="text" name="name" class="form-control" placeholder="name" value="{{ $data->name }}">
</div>
