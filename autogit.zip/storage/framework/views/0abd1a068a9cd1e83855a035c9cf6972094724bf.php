<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('cssplugin'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('contents/admin')); ?>/assets/plugins/summernote/dist/summernote-bs4.css" />
    <?php $__env->stopPush(); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-6">
                            <h5 class="card-title">Area of Practice</h5>
                        </div>
                        <div class="col-6">
                            <a href="<?php echo e(route('admin_area_of_practice_index')); ?>" class="btn btn-outline-tumblr float-right add_btn">
                                <i class="fa fa-arrow-left"></i>
                                back
                            </a>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin_area_of_practice_update')); ?>" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form_content">
                                <div class="form-group">
                                    <label for="input-1">Serial of view</label> <span class="text-danger"></span>
                                    <input type="number" name="serial" class="form-control" placeholder="serial" value="<?php echo e($data->serial); ?>">
                                </div>
                            </div>
                            <div class="form_content">
                                <div class="form-group">
                                    <label for="input-1">Title</label> <span class="text-danger"></span>
                                    <input type="text" name="title" class="form-control" placeholder="title" value="<?php echo e($data->title); ?>">
                                </div>
                            </div>
                            <div class="form_content">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-8">
                                            <label for="input-1">Icon</label> <span class="text-danger"></span>
                                            <input type="file" name="icon" class="form-control" placeholder="icon" value="">
                                        </div>
                                        <div class="col-4">
                                            <img src="<?php echo e(asset(''.$data->icon)); ?>" alt="icon" style="height: 40px;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form_content">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-8">
                                            <label for="input-1">Related Image</label> <span class="text-danger"></span>
                                            <input type="file" name="image" class="form-control" placeholder="image" value="">
                                        </div>
                                        <div class="col-4">
                                            <img src="<?php echo e(asset(''.$data->image)); ?>" alt="image" style="height: 40px;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="input-1">Description</label> <span class="text-danger"></span>
                                <textarea name="description" id="" class="form-control description"><?php echo e($data->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn update_btn btn-light px-5"><i class="fa fa-upload"></i>
                                    Submit</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('jsplugin'); ?>
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/plugins/summernote/dist/summernote-bs4.min.js"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $(function() {
                $('.description').summernote({
                    height: 400,
                    tabsize: 2
                });
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/njahanlaw/public_html/resources/views/admin/website/area_of_practice/edit.blade.php ENDPATH**/ ?>