<?php $__env->startSection('content'); ?>



    <!-- Breadcrumbs Section Start -->
    <div class="rs-breadcrumbs innerbg10">
        <div class="container">
            <div class="breadcrumbs-inner text-center">
                <h1 class="breadcrumbs-title white-color">Service</h1>
                <ul class="breadcrumbs-meta">
                    <li><a href="/">Home</a></li>
                    <li>Service</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Section End -->

    <!-- Faq Section Start -->
    <div class="rs-faq inner pt-120 pb-120 md-pt-80 md-pb-80">
        <div class="container">
            <div class="row">
                

                <?php 
                    $services = App\AreaOfPractice::orderBy('serial','ASC')->where('status',1)->get();
                ?>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 md-mb-20">
                        <div class="white-bg mb-60">
                            <div class="content-wrap">

                                
                                
                                    <h3><?php echo e($item->title); ?></h3>
                                    <?php echo $item->description; ?>

                                    <br>
                                    <br>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <?php if($item->image): ?>
                            <img src="/<?php echo e($item->image); ?>" alt="image" class="img-fluid">
                        <?php else: ?>
                        <?php endif; ?>
                        <br>
                        <br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </div>
        </div>
    </div>
    <!--Faq Section End-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xammp\htdocs\lawyer\resources\views/website/service.blade.php ENDPATH**/ ?>