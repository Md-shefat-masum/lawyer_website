<?php $__env->startSection('content'); ?>
    <?php $__env->startPush('cssplugin'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('contents/admin')); ?>/assets/plugins/summernote/dist/summernote-bs4.css" />
    <?php $__env->stopPush(); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-6">
                            <h5 class="card-title">Descriptive About</h5>
                        </div>
                        <div class="col-6">
                            
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="card-body">
                        <form action="<?php echo e(route('admin_descriptive_about_update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form_content">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-8">
                                            <label for="input-1">Page Banner</label> <span class="text-danger"></span>
                                            <input type="file" name="banner" class="form-control" placeholder="image" value="<?php echo e(old('image')); ?>">
                                        </div>
                                        <div class="col-4">
                                            <img src="<?php echo e(asset(''.$short_about->banner)); ?>" alt="image" style="height: 70px;">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-8">
                                            <label for="input-1">Profile Image</label> <span class="text-danger"></span>
                                            <input type="file" name="image" class="form-control" placeholder="image" value="<?php echo e(old('image')); ?>">
                                        </div>
                                        <div class="col-4">
                                            <img src="<?php echo e(asset(''.$short_about->image)); ?>" alt="image" style="height: 70px;">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="input-1">Description</label> <span class="text-danger"></span>
                                    <textarea name="description" id="" class="form-control description"><?php echo e($short_about->description); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn update_btn btn-light px-5"><i class="fa fa-upload"></i>
                                    Submit</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        
                    </div>
                </div>
            </div>
        </div>
    </div>


    <?php $__env->startPush('jsplugin'); ?>
        <script src="<?php echo e(asset('contents/admin')); ?>/assets/plugins/summernote/dist/summernote-bs4.min.js"></script>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $(function() {
                $('.description').summernote({
                    height: 400,
                    tabsize: 2
                });
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/descriptive_about/index.blade.php ENDPATH**/ ?>