<div class="free-consultation " id="free-consultation">
    <div class="sec-title mb-45 xs-mb-31 ">
        <div class="sub-title primary ">Schedule For</div>
        <h2 class="title white-color mb-0 ">Free Consultation</h2>
    </div>
    <form method="POST" action="<?php echo e(route('website_free_consultation_submit')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row ">
            <div class="col-md-6 ">
                <input type="text " name="name" placeholder="Your Name " required>
            </div>
            <div class="col-md-6 ">
                <input type="email " name="email" placeholder="Your Email " required>
            </div>
            <div class="col-md-6 ">
                <input type="text " name="phone" placeholder="Phone " required>
            </div>
            <div class="col-md-6 ">
                <input type="text " name="subject" placeholder="Subject " required>
            </div>
            <div class="col-md-6 col-0 d-none">
                <div class="select-option" >
                    <select name="law_name">
                        <?php $__currentLoopData = App\LawList::OrderBy('name','ASC')->where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-md-12 ">
                <textarea name="message" placeholder="Your Message " required></textarea>
            </div>
        </div>
        <div class="sunbmit-btn mt-30 ">
            <button class="readon upper " type="submit ">Submit request</button>
        </div>
    </form>
</div>

<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/website/home_page_include/free_consultation.blade.php ENDPATH**/ ?>