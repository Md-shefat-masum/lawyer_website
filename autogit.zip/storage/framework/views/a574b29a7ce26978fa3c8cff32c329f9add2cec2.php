
<div class="form-group">
    <label for="input-1">Email</label> <span class="text-danger">*</span>
    <input type="email" name="email" class="form-control" placeholder="email" value="<?php echo e(old('email')); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\lawyer\resources\views/admin/website/subscriber/add.blade.php ENDPATH**/ ?>