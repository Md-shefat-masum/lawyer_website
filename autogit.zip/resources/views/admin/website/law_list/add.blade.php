
<div class="form-group">
    <label for="input-1">Name</label> <span class="text-danger">*</span>
    <input type="text" name="name" class="form-control" placeholder="name" value="{{ old('name') }}">
</div>
