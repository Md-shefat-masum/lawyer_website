
<div class="form-group">
    <label for="input-1">Email</label> <span class="text-danger">*</span>
    <input type="email" name="email" class="form-control" placeholder="email" value="{{ old('email') }}">
</div>
