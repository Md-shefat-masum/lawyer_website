
<div class="form-group">
    <label for="input-1">Question</label> <span class="text-danger">*</span>
    <input type="text" name="question" class="form-control" placeholder="Question" value="{{ old('question') }}">
</div>
<div class="form-group">
    <label for="input-1">Answer</label> <span class="text-danger">*</span>
    <input type="text" name="answer" class="form-control" placeholder="answer" value="{{ old('answer') }}">
</div>
